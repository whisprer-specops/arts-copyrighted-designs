# Contested Ground

*An algorithmic philosophy for disputed surfaces.*

---

## The movement

Every pixel is disputed territory. Not shared, not blended — **disputed**. Several
fields of colour lay claim to the same point in space, each one a whole sheet of
noise extending past the edges of the frame in every direction, and only one of
them can hold any given point at any given instant. The image you see is not a
composition. It is the *decision surface* of an argument: a map of who is currently
winning, everywhere, all at once.

The decision is made by a single ruthless operator — argmax. No alpha, no mix, no
soft light. The strongest claim takes the ground outright. That ruthlessness is
what produces the hard, papery edges of real camouflage, and it is why the same
algorithm that generates a quiet forest disruptive pattern can, with two parameters
moved, generate something that hurts to look at. Blending produces mud. Winner-takes-all
produces *cloth*. This distinction is the whole discipline of the movement, and every
parameter in the meticulously crafted implementation exists to serve it.

## Motion without velocity

Each claimant sheet translates rigidly, at its own speed, along its own heading.
Nothing morphs. Nothing is reborn each frame. The fields are eternal and infinite;
only the window onto them moves. This constraint is not an optimisation — it is the
soul of the piece. A sheet that slides intact reads to the visual system as a
*physical object passing behind another physical object*, and that reading is what
gives the work its impossible depth: flat noise fields, no z-axis, no lighting model,
and yet the eye insists it is watching layered fabric slide over layered fabric.

Here is the quiet, carefully placed conceptual seed, the thing that took countless
iterations of refinement to get exactly right: **the boundaries move at a velocity
that belongs to no layer.** Where two drifting fields cross, their contour of equality
travels at a phase velocity determined by both — a moiré velocity, often faster than
either sheet, sometimes perpendicular to both, occasionally against the traffic
entirely. The eye locks onto the moving edge because edges are what eyes track. The
edge is a ghost. This is precisely the trick that dazzle camouflage played on optical
rangefinders in 1917: the point was never to hide the ship, it was to make its
heading and speed unsolvable. A viewer of this work cannot recover a single motion
vector from it, because there isn't one. There never was.

## Emergence from austerity

The philosophy demands austerity in the algorithm and extravagance in the result.
Fractal value noise, a rotation between octaves, one argmax, one margin. That margin —
the gap between the winning claim and the runner-up — is the only derived quantity in
the entire system, and it is asked to do an enormous amount of work: it draws the seam
where it approaches zero, it shades the relief where it is small, it holds the flat
interior where it is large. Depth, outline and body all fall out of a single
subtraction. Anything that cannot be earned from that subtraction does not belong in
the implementation. This is the discipline of an artist at the top of their field:
not adding features, but discovering how much a well-chosen quantity already contains.

## Parametric temperament

The system is built so that a handful of numbers move it across an entire territory
of appearances. Patch size and detail set whether the ground reads as lichen, as
gravel, or as continental plates. Quantising the sample point to a block turns organic
mottle into issued kit. A directional term folded into each sheet — banding
perpendicular to that sheet's own heading — bends the vocabulary from disruptive
woodland toward hard geometric dazzle, and because each sheet gets its *own* heading,
cranking it does not produce stripes: it produces an argument between stripes. Every
range was found by painstaking exploration, refined until the full sweep of each
slider stays inside the family and nothing in the space is ugly.

## Reproducibility as a promise

A seed fixes the temperament of the sheets — their headings, their relative speeds,
their scales, their positions in the infinite field — and it fixes them absolutely.
The same seed with the same parameters is the same artwork, on any machine, forever.
The palette is held separately and deliberately, because colour is an argument about
climate and the geometry is an argument about weather, and a master-level generative
system keeps those two conversations apart. Explore the seed space for form. Explore
the palette for mood. Beauty here is not a frame that was captured; it is a process
that continues whether or not anyone is watching.
