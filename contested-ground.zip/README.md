# Contested Ground — flowing layered camouflage

A single self-contained HTML file. Fractal noise sheets drift past each other on
different headings; every pixel goes to whichever sheet is currently winning it.
No blending, so the seams stay knife-sharp — and because the seams live where two
*moving* sheets tie, they travel at a velocity that belongs to neither. That's the
dazzle effect: there is no single motion vector to solve for.

## Run it

No toolchain, no build, no server. Double-click `contested-ground.html`, or:

```powershell
# Windows 11
start contested-ground.html
```

```bash
# Linux (Lubuntu / DragonOS)
xdg-open contested-ground.html
```

If you want to edit it live in VS Code, the Live Server extension works, but plain
`file://` is enough — there are no fetches and no modules.

Requirements: any browser with WebGL 1. p5.js 1.11.13 loads from cdnjs, so first run
needs a network. To go fully offline, download `p5.min.js` next to the HTML and change
the `<script src=...>` to `p5.min.js`.

## The whole algorithm

Four lines, in the fragment shader:

```glsl
for each sheet i:  v[i] = fbm( (pixel + drift[i]*phase) * scale[i] ) + bias[i]
winner            = argmax(v)
margin            = best - runnerUp
colour            = palette[winner], shaded by margin, mottled by noise
```

`margin` does all the visible work on its own: near zero it draws the seam, small it
shades the relief, large it leaves the flat body of the patch alone. Depth, outline
and interior all fall out of one subtraction.

## Where to poke

Open the file and look for `const CONFIG = {`. Everything is there, commented. The
sidebar sliders write to the same object, so you can find a look by dragging, read the
numbers off the labels, then paste them into `CONFIG` as your new defaults.

| Knob | What it does |
|---|---|
| `blob` | noise cycles per pixel — **bigger number, smaller patches** |
| `cell` | quantise the sample point to N-px blocks. `1` = organic, `8` = issued kit |
| `detail` / `rough` / `lac` | fbm octaves, gain, frequency step. Shape of the blobs |
| `layers` | how many colour sheets compete (2–8) |
| `speed` | global multiplier on every sheet's drift |
| `warp` / `warpScale` | slow shear of the whole field. Adds liquid confusion |
| `stripe` / `stripeFreq` | banding folded into each sheet **along its own heading**. Crank it and you get an argument between stripes, not stripes |
| `edge` / `edgeMix` / `edgeColor` | the seam between patches. Dark seam reads as *layers*, light seam reads as hard dazzle |
| `depth` | darkening as a patch nears its own boundary — fake occlusion, sells the layering |
| `grain` / `grainScale` | mottle inside each patch. Travels with the winning sheet |
| `colors` / `bias` | palette, and how greedy each sheet is. Negative bias = rare slivers |

Presets in the sidebar (`PRESETS` in the source) are just overrides on `CONFIG`:
Recon, Digital, Dazzle, Tidal, Arctic, Ember.

Keyboard: `space` pause · `s` save PNG · `r` random seed.

## Reproducibility

`seed` fixes each sheet's heading, speed, scale and position in the field, absolutely.
Same seed + same parameters = the same artwork, on any machine. The palette is held
separately from the seed on purpose: seed for form, palette for mood. "Palette from
seed" derives one if you want them coupled.

## Assumptions

- Rendered on the GPU as a WebGL 1 fragment shader — that's what buys 60 fps at full
  canvas resolution with eight sheets live.
- Canvas is square and sized to its container, capped at 1000 px, `pixelDensity` capped
  at 1.5 so a high-DPI panel doesn't quadruple the fragment count.
- Colours are straight sRGB, no gamma-correct blending. Deliberate: the argmax never
  mixes two colours, so there's nothing to get wrong, and the flat swatches match the
  reference photo better this way.

## The one risk worth knowing

Cost is fixed at eight sheets × five octaves per fragment whatever `layers` and
`detail` are set to — the loops are constant-bounded because GLSL ES 1.0 wants them
that way, and switched-off sheets are disqualified with a sentinel bias rather than
skipped. So you can't buy frame rate back by turning layers down. If you need it on
weak hardware (phone, integrated graphics at 4K), shrink the canvas or drop
`#define MAXO 5` to `3` in the shader — that's the real lever.

Second, smaller one: `Save PNG` is a script-initiated download. It works when you open
the file locally; a sandboxed iframe may block it.
